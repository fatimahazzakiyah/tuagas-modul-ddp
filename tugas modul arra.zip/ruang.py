from math import *

def balok(p, l, t):
    return 2 * ((p*l)+(p*t)+(l*t))
def kubus(s):
    return 6 * s**2
def tabung(r, t):
    return 2 * pi * r * (r + t)
def kerucut(r ,s):
    return pi * r * (r+s)
def bola(r):
    return 4 * pi * r**2

