import math

def persegi(s):
    return s * s
    
def lingkaran(r):
    return 3.14 * (r ** 2)

def segitiga(a, t):
    (a * t) / 2

def persegi_panjang(p, l):
    return p * l

def trapesium(a, b, t):
    return ((a + b) * t) / 2
    
    
